import random
import math
from fractions import Fraction

print("=" * 70)
print("RAND10算法期望值的精确推导（优化版本）")
print("=" * 70)

print("""
问题：求该算法在稳态下，平均每次rand10()输出需要多少次rand7()调用。

算法分析：
---------
def rand10(self):
    while True:
        self.v = self.v * 7 + self.rand7() - 1
        self.scale *= 7
        if self.scale >= 10:
            limit = (self.scale // 10) * 10
            if self.v < limit:
                res = self.v % 10
                self.v = self.v // 10
                self.scale = self.scale // 10
                return res + 1
            else:
                self.v -= limit
                self.scale -= limit
""")

print()
print("=" * 70)
print("第一步：状态空间分析")
print("=" * 70)

print("""
定义状态 (v, scale)，其中 0 <= v < scale。

每次循环：
1. 调用 rand7()，v' = v*7 + r, scale' = scale*7
2. 检查 scale' >= 10：
   - limit = (scale' // 10) * 10
   - 若 v' < limit：输出，余数状态 (v' // 10, scale' // 10)
   - 若 v' >= limit：拒绝，余数状态 (v' - limit, scale' - limit)
""")

states = set()
state_list = []

def add_state(v, scale):
    state = (v, scale)
    if state not in states:
        states.add(state)
        state_list.append(state)
        return True
    return False

add_state(0, 1)

idx = 0
while idx < len(state_list):
    v, scale = state_list[idx]
    idx += 1
    
    for r in range(7):
        new_v = v * 7 + r
        new_scale = scale * 7
        
        if new_scale >= 10:
            limit = (new_scale // 10) * 10
            if new_v < limit:
                rem_v = new_v // 10
                rem_scale = new_scale // 10
                add_state(rem_v, rem_scale)
            else:
                rem_v = new_v - limit
                rem_scale = new_scale - limit
                add_state(rem_v, rem_scale)
        else:
            add_state(new_v, new_scale)

state_to_idx = {s: i for i, s in enumerate(state_list)}
n = len(state_list)

print(f"总状态数: {n}")

by_scale = {}
for v, scale in state_list:
    if scale not in by_scale:
        by_scale[scale] = []
    by_scale[scale].append(v)

print(f"\n按 scale 分组的状态数:")
for scale in sorted(by_scale.keys()):
    print(f"  scale={scale}: {len(by_scale[scale])} 个状态")

print()
print("=" * 70)
print("第二步：建立期望值方程 E(v, scale)")
print("=" * 70)

print("""
定义 E(v, scale) = 从状态 (v, scale) 出发到输出所需的期望 rand7() 调用次数。

方程：
E(v, scale) = 1 + (1/7) * sum_{r=0}^{6} f(v, scale, r)

其中 f(v, scale, r) 是调用 rand7() 得到 r 后的贡献：
- 若输出：f = 0（已输出，不需要更多调用）
- 若拒绝：f = E(余数状态)
- 若继续累积：f = E(下一状态)
""")

A = [[Fraction(0) for _ in range(n)] for _ in range(n)]
b = [Fraction(0) for _ in range(n)]

for i, (v, scale) in enumerate(state_list):
    A[i][i] = Fraction(1)
    b[i] = Fraction(1)
    
    for r in range(7):
        new_v = v * 7 + r
        new_scale = scale * 7
        
        if new_scale >= 10:
            limit = (new_scale // 10) * 10
            if new_v < limit:
                pass
            else:
                rem_v = new_v - limit
                rem_scale = new_scale - limit
                if (rem_v, rem_scale) in state_to_idx:
                    j = state_to_idx[(rem_v, rem_scale)]
                    A[i][j] -= Fraction(1, 7)
        else:
            if (new_v, new_scale) in state_to_idx:
                j = state_to_idx[(new_v, new_scale)]
                A[i][j] -= Fraction(1, 7)

def solve_linear_system(A, b):
    n = len(A)
    for col in range(n):
        max_row = col
        for row in range(col + 1, n):
            if abs(A[row][col]) > abs(A[max_row][col]):
                max_row = row
        A[col], A[max_row] = A[max_row], A[col]
        b[col], b[max_row] = b[max_row], b[col]
        
        if A[col][col] == 0:
            continue
        
        for row in range(col + 1, n):
            if A[row][col] != 0:
                factor = A[row][col] / A[col][col]
                for j in range(col, n):
                    A[row][j] -= factor * A[col][j]
                b[row] -= factor * b[col]
    
    x = [Fraction(0) for _ in range(n)]
    for i in range(n - 1, -1, -1):
        if A[i][i] == 0:
            x[i] = Fraction(0)
        else:
            x[i] = b[i]
            for j in range(i + 1, n):
                x[i] -= A[i][j] * x[j]
            x[i] /= A[i][i]
    
    return x

E = solve_linear_system(A, b)
E_dict = {state_list[i]: E[i] for i in range(n)}

print("\n求解得到的 E(v, scale)（scale < 10 的状态）:")
for scale in sorted(by_scale.keys()):
    if scale < 10:
        print(f"\nscale={scale}:")
        for v in sorted(by_scale[scale]):
            print(f"  E({v}, {scale}) = {E_dict[(v, scale)]} = {float(E_dict[(v, scale)]):.6f}")

print()
print("=" * 70)
print("第三步：计算转移概率矩阵")
print("=" * 70)

print("""
定义 P(s, s') = 从状态 s 出发，最终输出后落在状态 s' 的概率。

使用迭代法计算：从每个状态出发，模拟所有可能的路径，直到输出。
""")

output_states = [(v, s) for v, s in state_list if s < 10]
m = len(output_states)
output_state_to_idx = {s: i for i, s in enumerate(output_states)}

print(f"\n输出后可能的余数状态（scale < 10）: {m} 个状态")

def get_next_state(v, scale, r):
    """从状态(v, scale)出发，调用rand7()得到r后的下一状态和是否输出"""
    new_v = v * 7 + r
    new_scale = scale * 7
    
    if new_scale >= 10:
        limit = (new_scale // 10) * 10
        if new_v < limit:
            rem_v = new_v // 10
            rem_scale = new_scale // 10
            return ('output', (rem_v, rem_scale))
        else:
            rem_v = new_v - limit
            rem_scale = new_scale - limit
            return ('reject', (rem_v, rem_scale))
    else:
        return ('continue', (new_v, new_scale))

def compute_transition_prob(start_state, output_states, max_iter=50):
    """计算从start_state出发，最终输出后落在各output_state的概率"""
    result = {s: Fraction(0) for s in output_states}
    
    current = {start_state: Fraction(1)}
    
    for iteration in range(max_iter):
        if not current:
            break
        
        next_level = {}
        
        for state, prob in current.items():
            v, scale = state
            
            for r in range(7):
                status, next_state = get_next_state(v, scale, r)
                
                if status == 'output':
                    if next_state in result:
                        result[next_state] += prob * Fraction(1, 7)
                elif status == 'reject' or status == 'continue':
                    if next_state not in next_level:
                        next_level[next_state] = Fraction(0)
                    next_level[next_state] += prob * Fraction(1, 7)
        
        current = next_level
    
    return result

P_matrix = [[Fraction(0) for _ in range(m)] for _ in range(m)]

print("\n计算转移概率...")
for i, start_state in enumerate(output_states):
    probs = compute_transition_prob(start_state, output_states)
    for j, end_state in enumerate(output_states):
        P_matrix[i][j] = probs[end_state]

print("\n转移概率矩阵 P[i][j]（部分显示）:")
for i in range(min(5, m)):
    print(f"  从 {output_states[i]}:", end="")
    for j in range(min(5, m)):
        print(f" {float(P_matrix[i][j]):.4f}", end="")
    print(" ...")

print()
print("=" * 70)
print("第四步：求解稳态分布")
print("=" * 70)

print("""
稳态分布 pi 满足：
  pi = pi * P

即：pi(j) = sum_i pi(i) * P(i, j)

加上归一化条件：sum_i pi(i) = 1
""")

P_eq = [[Fraction(0) for _ in range(m + 1)] for _ in range(m)]

for i in range(m):
    for j in range(m):
        P_eq[i][j] = P_matrix[j][i]
    P_eq[i][i] -= Fraction(1)

for j in range(m):
    P_eq[m-1][j] = Fraction(1)
P_eq[m-1][m] = Fraction(1)

for i in range(m-1):
    P_eq[i][m] = Fraction(0)

A_pi = [[P_eq[i][j] for j in range(m)] for i in range(m)]
b_pi = [P_eq[i][m] for i in range(m)]

pi = solve_linear_system(A_pi, b_pi)

print("稳态分布 pi（非零项）:")
for i, state in enumerate(output_states):
    if float(pi[i]) > 0.001:
        print(f"  pi{state} = {float(pi[i]):.10f}")

print(f"\n检验 sum(pi) = {float(sum(pi)):.10f}")

print()
print("=" * 70)
print("第五步：计算稳态期望值")
print("=" * 70)

print("""
稳态期望值：
  E_steady = sum_i pi(i) * E(i)
""")

E_steady = Fraction(0)
print("\n计算过程（非零项）:")
for i, state in enumerate(output_states):
    contribution = pi[i] * E_dict[state]
    E_steady += contribution
    if float(pi[i]) > 0.001:
        print(f"  pi{state} * E{state} = {float(pi[i]):.6f} * {float(E_dict[state]):.6f} = {float(contribution):.6f}")

print(f"\n稳态期望值 E_steady = {E_steady}")
print(f"稳态期望值 E_steady = {float(E_steady):.10f}")

print()
print("=" * 70)
print("第六步：蒙特卡洛验算")
print("=" * 70)

class Solution:
    def __init__(self):
        self.v = 0
        self.scale = 1
        self.rand7_calls = 0
    
    def rand7(self):
        self.rand7_calls += 1
        return random.randint(1, 7)
    
    def rand10(self):
        while True:
            self.v = self.v * 7 + self.rand7() - 1
            self.scale *= 7
            if self.scale >= 10:
                limit = (self.scale // 10) * 10
                if self.v < limit:
                    res = self.v % 10
                    self.v = self.v // 10
                    self.scale = self.scale // 10
                    return res + 1
                else:
                    self.v -= limit
                    self.scale -= limit

def simulate(n_trials):
    sol = Solution()
    for _ in range(n_trials):
        sol.rand10()
    return sol.rand7_calls / n_trials

print("\n蒙特卡洛模拟:")
for n in [10000, 50000, 100000]:
    avg = simulate(n)
    print(f"Trials: {n:>8}, Average: {avg:.6f}")

print()
print("=" * 70)
print("最终结果")
print("=" * 70)

print(f"""
精确推导结果：
  稳态期望值 E = {E_steady}
  稳态期望值 E ≈ {float(E_steady):.6f}

蒙特卡洛验算：
  约为 {float(E_steady):.3f}
""")
