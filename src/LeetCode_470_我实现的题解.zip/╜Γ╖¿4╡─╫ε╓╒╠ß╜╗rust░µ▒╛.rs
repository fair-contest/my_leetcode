use std::cell::RefCell;

thread_local! {
    static STATE: RefCell<(i32, i32)> = RefCell::new((0, 1));
}

impl Solution {
    pub fn rand10() -> i32 {
        const BUFFER: i32 = 10000;
        
        loop {
            let (mut v, mut cap) = STATE.with(|s| {
                let state = s.borrow();
                (state.0, state.1)
            });

            // 熵累积：仅当状态空间不足时扩展
            while cap < BUFFER {
                v = v * 7 + rand7() - 1;
                cap *= 7;
            }

            let limit = (cap / 10) * 10;

            if v < limit {
                let res = v % 10;
                v /= 10;
                cap /= 10;
                STATE.with(|s| {
                    let mut state = s.borrow_mut();
                    state.0 = v;
                    state.1 = cap;
                });
                return res + 1;
            } else {
                v -= limit;
                cap -= limit;
                STATE.with(|s| {
                    let mut state = s.borrow_mut();
                    state.0 = v;
                    state.1 = cap;
                });
            }
        }
    }
}
