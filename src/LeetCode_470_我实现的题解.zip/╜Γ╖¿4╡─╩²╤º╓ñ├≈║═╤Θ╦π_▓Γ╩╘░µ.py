import random
import math

print("=" * 70)
print("延迟提取策略的均匀性数学证明")
print("=" * 70)

print("""
问题：证明延迟提取策略生成的每个数字都是等概率的。

算法回顾：
=========
class Solution:
    def __init__(self):
        self.v = 0
        self.scale = 1
        self.cache = []
    
    def rand10(self):
        if self.cache:
            return self.cache.pop()
        
        while True:
            while self.scale < THRESHOLD:  # 延迟提取
                self.v = self.v * 7 + rand7() - 1
                self.scale *= 7
            
            while self.scale >= 10:
                limit = (self.scale // 10) * 10
                if self.v < limit:
                    self.cache.append((self.v % 10) + 1)
                    self.v = self.v // 10
                    self.scale = self.scale // 10
                else:
                    self.v -= limit
                    self.scale -= limit
                    break
            
            if self.cache:
                return self.cache.pop()
""")

print()
print("=" * 70)
print("数学证明")
print("=" * 70)

print("""
定义和引理：
===========

定义1：状态 (v, scale) 表示当前累积的值为 v，状态空间大小为 scale。

定义2：均匀状态 - 如果 v 在 [0, scale-1] 范围内均匀分布，则称状态 (v, scale) 是均匀的。

引理1：扩展操作保持均匀性
-------------------------
如果状态 (v, scale) 是均匀的，则扩展后的状态 (v', scale*7) 也是均匀的，
其中 v' = v * 7 + r，r 是 rand7() - 1 的结果。

证明：
- v 在 [0, scale-1] 中均匀分布
- r 在 [0, 6] 中均匀分布
- v' = v * 7 + r 在 [0, scale*7-1] 中均匀分布
- 因为每个 (v, r) 组合对应唯一的 v'，且所有组合等概率
- 因此 (v', scale*7) 是均匀的。QED

引理2：提取操作保持均匀性
-------------------------
如果状态 (v, scale) 是均匀的且 scale >= 10，设 limit = (scale // 10) * 10，
则：
(a) 若 v < limit，输出 (v % 10) + 1，新状态 (v // 10, scale // 10) 是均匀的
(b) 若 v >= limit，新状态 (v - limit, scale - limit) 是均匀的

证明(a)：
- v 在 [0, limit-1] 中均匀分布（因为 v < limit 且原状态均匀）
- limit 是 10 的倍数
- v mod 10 在 [0, 9] 中均匀分布（因为 [0, limit-1] 中每个 mod 10 值出现 limit/10 次）
- 因此输出 (v % 10) + 1 是均匀的
- v // 10 在 [0, limit/10-1] 中均匀分布
- 因此新状态 (v // 10, scale // 10) 是均匀的。QED

证明(b)：
- v 在 [limit, scale-1] 中均匀分布（条件分布）
- v - limit 在 [0, scale-limit-1] 中均匀分布
- 因此新状态 (v - limit, scale - limit) 是均匀的。QED

引理3：延迟提取不破坏均匀性
---------------------------
无论阈值 THRESHOLD 是多少，只要在 scale >= 10 时进行提取，
输出都是均匀的。

证明：
- 初始状态 (0, 1) 是均匀的（平凡情况）
- 扩展到 scale >= THRESHOLD 的过程中，每步扩展都保持均匀性（引理1）
- 提取时，输出是均匀的（引理2a）
- 拒绝后的新状态是均匀的（引理2b）
- 继续扩展时，均匀性保持（引理1）
- 因此，无论 THRESHOLD 是多少，输出都是均匀的。QED
""")

print()
print("=" * 70)
print("更详细的证明：输出概率计算")
print("=" * 70)

print("""
定理：延迟提取策略生成的每个数字的概率都是 1/10。

证明：
=====

设 THRESHOLD 为任意正整数。

考虑一次完整的提取过程：

1. 初始状态：(0, 1)，均匀

2. 扩展阶段：
   - 每次调用 rand7()，状态变为 (v*7 + r, scale*7)
   - 由引理1，均匀性保持
   - 最终状态 (v, scale) 满足 scale >= THRESHOLD，且均匀

3. 提取阶段：
   - 设 limit = (scale // 10) * 10
   - P(v < limit) = limit / scale
   - P(v >= limit) = (scale - limit) / scale
   
   若 v < limit：
   - 输出 (v % 10) + 1
   - v 在 [0, limit-1] 中均匀
   - limit 是 10 的倍数
   - P(输出 = k) = (limit/10) / limit = 1/10，对于 k = 1, 2, ..., 10
   
   若 v >= limit：
   - 新状态 (v - limit, scale - limit) 均匀
   - 继续扩展和提取

4. 递归分析：
   设 P_k 为输出 k 的概率。
   
   在任意均匀状态 (v, scale)：
   P(输出 k | v < limit) = 1/10
   
   因此：
   P_k = P(v < limit) * (1/10) + P(v >= limit) * P_k'
   
   其中 P_k' 是拒绝后继续提取得到 k 的概率。
   
   由于拒绝后的状态也是均匀的，所以 P_k' = P_k。
   
   因此：
   P_k = P(v < limit) * (1/10) + P(v >= limit) * P_k
   P_k * (1 - P(v >= limit)) = P(v < limit) * (1/10)
   P_k * P(v < limit) = P(v < limit) * (1/10)
   P_k = 1/10

   这证明了每个输出的概率都是 1/10。QED
""")

print()
print("=" * 70)
print("数值验证")
print("=" * 70)

def simulate_detailed(sol_class, n_trials):
    sol = sol_class()
    counts = [0] * 10
    for _ in range(n_trials):
        counts[sol.rand10() - 1] += 1
    return counts

def create_delayed_solution(threshold):
    class Solution:
        def __init__(self):
            self.v = 0
            self.scale = 1
            self.cache = []
            self.rand7_calls = 0
        
        def rand7(self):
            self.rand7_calls += 1
            return random.randint(1, 7)
        
        def rand10(self):
            if self.cache:
                return self.cache.pop()
            
            while True:
                while self.scale < threshold:
                    self.v = self.v * 7 + self.rand7() - 1
                    self.scale *= 7
                
                while self.scale >= 10:
                    limit = (self.scale // 10) * 10
                    if self.v < limit:
                        self.cache.append((self.v % 10) + 1)
                        self.v = self.v // 10
                        self.scale = self.scale // 10
                    else:
                        self.v -= limit
                        self.scale -= limit
                        break
                
                if self.cache:
                    return self.cache.pop()
    return Solution

print("\n不同阈值下的输出分布（100万次试验）:")
for threshold in [10, 49, 343, 2000]:
    sol_class = create_delayed_solution(threshold)
    counts = simulate_detailed(sol_class, 1000000)
    expected = 100000
    max_dev = max(abs(c - expected) / expected for c in counts)
    chi_sq = sum((c - expected) ** 2 / expected for c in counts)
    
    print(f"\n阈值 = {threshold}:")
    print(f"  输出分布: {[f'{c/10000:.2f}%' for c in counts]}")
    print(f"  最大偏差: {max_dev*100:.2f}%")
    print(f"  卡方统计量: {chi_sq:.2f} (临界值=16.92)")

print()
print("=" * 70)
print("结论")
print("=" * 70)

print("""
数学证明结论：
=============

1. 扩展操作保持均匀性：如果状态 (v, scale) 均匀，则扩展后仍均匀。

2. 提取操作保持均匀性：
   - 输出 (v % 10) + 1 是均匀的（因为 limit 是 10 的倍数）
   - 拒绝后的新状态仍均匀

3. 延迟提取不破坏均匀性：
   - 无论阈值是多少，只要在 scale >= 10 时提取，输出都是均匀的

4. 每个数字的输出概率严格等于 1/10。

关键洞察：
==========
延迟提取只是改变了"何时提取"，而不是"如何提取"。
提取时的逻辑完全相同，因此均匀性保持不变。

延迟提取的优势在于：
- 减少了"输出后状态太小需要重新扩展"的情况
- 提高了信息利用效率
- 但不影响输出的均匀性
""")
