import random
import math
from fractions import Fraction

print("=" * 70)
print("RAND10算法期望值的精确推导（版本3 - 非持久化状态）")
print("=" * 70)

print("""
问题：求该算法平均每次rand10()输出需要多少次rand7()调用。

算法分析：
---------
def rand10(self):
    idx = 0          # 当前状态值
    max_val = 1      # 当前状态空间大小（初始为1个隐含状态）
    
    while True:
        # 连续扩展状态空间，直到 max_val >= 10
        while max_val < 10:
            idx = idx * 7 + rand7() - 1
            max_val *= 7
            
        # 取最大10的倍数作为接受区间
        threshold = (max_val // 10) * 10
        if idx < threshold:
            return (idx % 10) + 1  # 严格均匀映射到 [1, 10]
        
        # 拒绝后，保留剩余状态，max_val 同步缩减
        idx = idx - threshold
        max_val = max_val - threshold
        # 循环继续，状态不重置，自然进入下一轮扩展

关键区别：
- 每次调用 rand10() 时，idx 和 max_val 从 0 和 1 开始
- 拒绝后状态保留在 idx 和 max_val 中，继续扩展
- 但下次调用 rand10() 时状态重置
""")

print()
print("=" * 70)
print("第一步：状态空间分析")
print("=" * 70)

print("""
定义状态 (idx, max_val)，其中 0 <= idx < max_val。

状态转移规则：
1. 扩展阶段：若 max_val < 10，调用 rand7()
   idx' = idx * 7 + r, max_val' = max_val * 7
   
2. 检查阶段：若 max_val >= 10
   threshold = (max_val // 10) * 10
   - 若 idx < threshold：输出
   - 若 idx >= threshold：idx -= threshold, max_val -= threshold

注意：每次调用 rand10() 从 (0, 1) 开始，状态不持久化。
""")

states = set()
state_list = []

def add_state(idx, max_val):
    state = (idx, max_val)
    if state not in states:
        states.add(state)
        state_list.append(state)
        return True
    return False

add_state(0, 1)

idx = 0
while idx < len(state_list):
    s_idx, s_max = state_list[idx]
    idx += 1
    
    if s_max < 10:
        for r in range(7):
            new_idx = s_idx * 7 + r
            new_max = s_max * 7
            add_state(new_idx, new_max)
    else:
        threshold = (s_max // 10) * 10
        if s_idx >= threshold:
            new_idx = s_idx - threshold
            new_max = s_max - threshold
            add_state(new_idx, new_max)

state_to_idx = {s: i for i, s in enumerate(state_list)}
n = len(state_list)

print(f"总状态数: {n}")

by_max_val = {}
for idx, max_val in state_list:
    if max_val not in by_max_val:
        by_max_val[max_val] = []
    by_max_val[max_val].append(idx)

print(f"\n按 max_val 分组的状态数:")
for max_val in sorted(by_max_val.keys())[:20]:
    print(f"  max_val={max_val}: {len(by_max_val[max_val])} 个状态")
if len(by_max_val) > 20:
    print(f"  ... (共 {len(by_max_val)} 个不同的 max_val)")

print()
print("=" * 70)
print("第二步：建立期望值方程 E(idx, max_val)")
print("=" * 70)

print("""
定义 E(idx, max_val) = 从状态 (idx, max_val) 出发到输出所需的期望 rand7() 调用次数。

方程：
1. 若 max_val < 10（扩展阶段）：
   E(idx, max_val) = 1 + (1/7) * sum_{r=0}^{6} E(idx*7+r, max_val*7)

2. 若 max_val >= 10（检查阶段）：
   threshold = (max_val // 10) * 10
   - 若 idx < threshold：E = 0（输出）
   - 若 idx >= threshold：E = E(idx - threshold, max_val - threshold)
""")

A = [[Fraction(0) for _ in range(n)] for _ in range(n)]
b = [Fraction(0) for _ in range(n)]

for i, (s_idx, s_max) in enumerate(state_list):
    A[i][i] = Fraction(1)
    
    if s_max < 10:
        b[i] = Fraction(1)
        for r in range(7):
            new_idx = s_idx * 7 + r
            new_max = s_max * 7
            j = state_to_idx[(new_idx, new_max)]
            A[i][j] -= Fraction(1, 7)
    else:
        threshold = (s_max // 10) * 10
        if s_idx < threshold:
            b[i] = Fraction(0)
        else:
            new_idx = s_idx - threshold
            new_max = s_max - threshold
            j = state_to_idx[(new_idx, new_max)]
            A[i][j] = Fraction(-1)
            b[i] = Fraction(0)

def solve_linear_system(A, b):
    n = len(A)
    for col in range(n):
        max_row = col
        for row in range(col + 1, n):
            if abs(A[row][col]) > abs(A[max_row][col]):
                max_row = row
        A[col], A[max_row] = A[max_row], A[col]
        b[col], b[max_row] = b[max_row], b[col]
        
        if A[col][col] == 0:
            continue
        
        for row in range(col + 1, n):
            if A[row][col] != 0:
                factor = A[row][col] / A[col][col]
                for j in range(col, n):
                    A[row][j] -= factor * A[col][j]
                b[row] -= factor * b[col]
    
    x = [Fraction(0) for _ in range(n)]
    for i in range(n - 1, -1, -1):
        if A[i][i] == 0:
            x[i] = Fraction(0)
        else:
            x[i] = b[i]
            for j in range(i + 1, n):
                x[i] -= A[i][j] * x[j]
            x[i] /= A[i][i]
    
    return x

E = solve_linear_system(A, b)
E_dict = {state_list[i]: E[i] for i in range(n)}

print("\n求解得到的 E(idx, max_val)（max_val < 10 的状态）:")
for max_val in sorted(by_max_val.keys()):
    if max_val < 10:
        print(f"\nmax_val={max_val}:")
        for idx in sorted(by_max_val[max_val]):
            print(f"  E({idx}, {max_val}) = {E_dict[(idx, max_val)]} = {float(E_dict[(idx, max_val)]):.6f}")

print()
print("=" * 70)
print("第三步：计算期望值")
print("=" * 70)

print("""
由于每次调用 rand10() 都从状态 (0, 1) 开始，
所以期望值就是 E(0, 1)。
""")

E_final = E_dict[(0, 1)]

print(f"\n期望值 E = {E_final}")
print(f"期望值 E = {float(E_final):.10f}")

print()
print("=" * 70)
print("第四步：蒙特卡洛验算")
print("=" * 70)

def rand7():
    return random.randint(1, 7)

class Solution:
    def __init__(self):
        self.rand7_calls = 0
    
    def rand7(self):
        self.rand7_calls += 1
        return random.randint(1, 7)
    
    def rand10(self):
        idx = 0
        max_val = 1
        
        while True:
            while max_val < 10:
                idx = idx * 7 + self.rand7() - 1
                max_val *= 7
            
            threshold = (max_val // 10) * 10
            if idx < threshold:
                return (idx % 10) + 1
            
            idx = idx - threshold
            max_val = max_val - threshold

def simulate(n_trials):
    total_calls = 0
    for _ in range(n_trials):
        sol = Solution()
        sol.rand10()
        total_calls += sol.rand7_calls
    return total_calls / n_trials

print("\n蒙特卡洛模拟:")
for n in [10000, 50000, 100000]:
    avg = simulate(n)
    print(f"Trials: {n:>8}, Average: {avg:.6f}")

print()
print("=" * 70)
print("最终结果")
print("=" * 70)

print(f"""
精确推导结果：
  期望值 E = {E_final}
  期望值 E ≈ {float(E_final):.6f}

蒙特卡洛验算：
  约为 {float(E_final):.3f}
""")
