import random
import math
from fractions import Fraction

print("=" * 70)
print("RAND10算法期望值的精确推导")
print("=" * 70)

print("""
问题：求该算法在稳态下，平均每次rand10()输出需要多少次rand7()调用。

关键：状态持久化，每次输出后的余数状态保留给下一次调用。
""")

print()
print("=" * 70)
print("第一步：状态空间分析")
print("=" * 70)

print("""
定义状态 (v, scale)，其中 0 <= v < scale。

状态转移规则：
1. 若 scale < 10：调用 rand7()，v' = v*7 + r, scale' = scale*7
2. 若 scale >= 10：
   - scale' = scale // 10
   - digit = v // scale'
   - 若 digit < 10：输出，余数状态 (v % scale', scale')
   - 若 digit >= 10：拒绝，余数状态 (v % scale', scale')
""")

states = set()
state_list = []

def add_state(v, scale):
    state = (v, scale)
    if state not in states:
        states.add(state)
        state_list.append(state)
        return True
    return False

add_state(0, 1)

idx = 0
while idx < len(state_list):
    v, scale = state_list[idx]
    idx += 1
    
    if scale >= 10:
        temp_scale = scale
        temp_v = v
        while temp_scale >= 10:
            temp_scale //= 10
            digit = temp_v // temp_scale
            temp_v = temp_v % temp_scale
            if digit < 10:
                break
        else:
            add_state(temp_v, temp_scale)
    else:
        for r in range(7):
            new_v = v * 7 + r
            new_scale = scale * 7
            add_state(new_v, new_scale)

state_to_idx = {s: i for i, s in enumerate(state_list)}
n = len(state_list)

print(f"总状态数: {n}")

print()
print("=" * 70)
print("第二步：建立期望值方程 E(v, scale)")
print("=" * 70)

print("""
定义 E(v, scale) = 从状态 (v, scale) 出发到输出所需的期望 rand7() 调用次数。

方程：
- 若可直接输出：E = 0
- 若被拒绝：E = E(余数状态)
- 若 scale < 10：E = 1 + (1/7) * sum E(下一状态)
""")

A = [[Fraction(0) for _ in range(n)] for _ in range(n)]
b = [Fraction(0) for _ in range(n)]

for i, (v, scale) in enumerate(state_list):
    A[i][i] = Fraction(1)
    
    if scale >= 10:
        temp_scale = scale
        temp_v = v
        while temp_scale >= 10:
            temp_scale //= 10
            digit = temp_v // temp_scale
            temp_v = temp_v % temp_scale
            if digit < 10:
                b[i] = Fraction(0)
                break
        else:
            j = state_to_idx[(temp_v, temp_scale)]
            A[i][j] = Fraction(-1)
            b[i] = Fraction(0)
    else:
        b[i] = Fraction(1)
        for r in range(7):
            new_v = v * 7 + r
            new_scale = scale * 7
            j = state_to_idx[(new_v, new_scale)]
            A[i][j] -= Fraction(1, 7)

def solve_linear_system(A, b):
    n = len(A)
    for col in range(n):
        max_row = col
        for row in range(col + 1, n):
            if abs(A[row][col]) > abs(A[max_row][col]):
                max_row = row
        A[col], A[max_row] = A[max_row], A[col]
        b[col], b[max_row] = b[max_row], b[col]
        
        if A[col][col] == 0:
            continue
        
        for row in range(col + 1, n):
            if A[row][col] != 0:
                factor = A[row][col] / A[col][col]
                for j in range(col, n):
                    A[row][j] -= factor * A[col][j]
                b[row] -= factor * b[col]
    
    x = [Fraction(0) for _ in range(n)]
    for i in range(n - 1, -1, -1):
        if A[i][i] == 0:
            x[i] = Fraction(0)
        else:
            x[i] = b[i]
            for j in range(i + 1, n):
                x[i] -= A[i][j] * x[j]
            x[i] /= A[i][i]
    
    return x

E = solve_linear_system(A, b)
E_dict = {state_list[i]: E[i] for i in range(n)}

print("\n求解得到的 E(v, scale)（scale < 10 的状态）:")
by_scale = {}
for v, scale in state_list:
    if scale not in by_scale:
        by_scale[scale] = []
    by_scale[scale].append(v)

for scale in [1, 2, 4, 7]:
    print(f"\nscale={scale}:")
    for v in sorted(by_scale[scale]):
        print(f"  E({v}, {scale}) = {E_dict[(v, scale)]} = {float(E_dict[(v, scale)]):.6f}")

print()
print("=" * 70)
print("第三步：建立输出后余数状态的转移概率方程")
print("=" * 70)

print("""
关键：计算从状态 s 出发，最终输出后落在各余数状态的概率。

定义 P(s, s') = 从状态 s 出发，最终输出后落在状态 s' 的概率。

方程：
1. 若从 s 可以直接输出，余数为 s'：
   P(s, s') = 1

2. 若从 s 被拒绝，余数为 s''：
   P(s, s') = P(s'', s')

3. 若 s 的 scale < 10：
   P(s, s') = (1/7) * sum_{r=0}^{6} P((v*7+r, scale*7), s')

这是一个线性方程组！
""")

output_states = [(v, s) for v, s in state_list if s < 10]
m = len(output_states)
output_state_to_idx = {s: i for i, s in enumerate(output_states)}

print(f"\n输出后可能的余数状态（scale < 10）: {output_states}")

def get_output_or_reject(v, scale):
    """返回 (是否输出, 余数状态)"""
    if scale < 10:
        return (None, None)
    
    temp_scale = scale
    temp_v = v
    
    while temp_scale >= 10:
        temp_scale //= 10
        digit = temp_v // temp_scale
        temp_v = temp_v % temp_scale
        
        if digit < 10:
            return ('output', (temp_v, temp_scale))
    
    return ('reject', (temp_v, temp_scale))

P_A = [[Fraction(0) for _ in range(m * n)] for _ in range(m * n)]
P_b = [Fraction(0) for _ in range(m * n)]

for i, end_state in enumerate(output_states):
    for j, start_state in enumerate(state_list):
        row = i * n + j
        P_A[row][row] = Fraction(1)
        
        v, scale = start_state
        
        if scale < 10:
            for r in range(7):
                new_v = v * 7 + r
                new_scale = scale * 7
                new_idx = state_to_idx[(new_v, new_scale)]
                P_A[row][i * n + new_idx] -= Fraction(1, 7)
        else:
            status, result = get_output_or_reject(v, scale)
            
            if status == 'output':
                if result == end_state:
                    P_b[row] = Fraction(1)
                else:
                    P_b[row] = Fraction(0)
            elif status == 'reject':
                rem_idx = state_to_idx[result]
                P_A[row][i * n + rem_idx] -= Fraction(1)

P_solution = solve_linear_system(P_A, P_b)

P_matrix = [[Fraction(0) for _ in range(m)] for _ in range(m)]

for i in range(m):
    for j in range(m):
        start_state = output_states[j]
        start_idx = state_to_idx[start_state]
        P_matrix[j][i] = P_solution[i * n + start_idx]

print("\n转移概率矩阵 P[i][j] = 从状态i出发，最终输出后落在状态j的概率:")
print("行：起始状态，列：结束状态")
print("\n     ", end="")
for j, s in enumerate(output_states):
    print(f"  {s}   ", end="")
print()
for i, s_i in enumerate(output_states):
    print(f"{s_i}:", end="")
    for j in range(m):
        print(f"  {float(P_matrix[i][j]):.4f}", end="")
    print()

print()
print("=" * 70)
print("第四步：求解稳态分布")
print("=" * 70)

print("""
稳态分布 pi 满足：
  pi = pi * P

即：pi(j) = sum_i pi(i) * P(i, j)

加上归一化条件：sum_i pi(i) = 1
""")

P_eq = [[Fraction(0) for _ in range(m + 1)] for _ in range(m)]

for i in range(m):
    for j in range(m):
        P_eq[i][j] = P_matrix[j][i]
    P_eq[i][i] -= Fraction(1)

for j in range(m):
    P_eq[m-1][j] = Fraction(1)
P_eq[m-1][m] = Fraction(1)

for i in range(m-1):
    P_eq[i][m] = Fraction(0)

A_pi = [[P_eq[i][j] for j in range(m)] for i in range(m)]
b_pi = [P_eq[i][m] for i in range(m)]

pi = solve_linear_system(A_pi, b_pi)

print("稳态分布 pi:")
for i, state in enumerate(output_states):
    print(f"  pi{state} = {pi[i]} = {float(pi[i]):.10f}")

print(f"\n检验 sum(pi) = {sum(pi)} = {float(sum(pi))}")

print()
print("=" * 70)
print("第五步：计算稳态期望值")
print("=" * 70)

print("""
稳态期望值：
  E_steady = sum_i pi(i) * E(i)
""")

E_steady = Fraction(0)
print("\n计算过程:")
for i, state in enumerate(output_states):
    contribution = pi[i] * E_dict[state]
    E_steady += contribution
    print(f"  pi{state} * E{state} = {pi[i]} * {E_dict[state]} = {contribution}")

print(f"\n稳态期望值 E_steady = {E_steady}")
print(f"稳态期望值 E_steady = {float(E_steady):.10f}")

print()
print("=" * 70)
print("第六步：蒙特卡洛验算")
print("=" * 70)

class Solution:
    def __init__(self):
        self.v = 0
        self.scale = 1
        self.rand7_calls = 0
    
    def rand7(self):
        self.rand7_calls += 1
        return random.randint(1, 7)
    
    def rand10(self):
        while True:
            self.v = self.v * 7 + self.rand7() - 1
            self.scale *= 7
            
            while self.scale >= 10:
                self.scale //= 10
                digit = self.v // self.scale
                self.v %= self.scale
                
                if digit < 10:
                    return digit + 1

def simulate(n_trials):
    sol = Solution()
    for _ in range(n_trials):
        sol.rand10()
    return sol.rand7_calls / n_trials

print("\n蒙特卡洛模拟:")
for n in [10000, 50000, 100000]:
    avg = simulate(n)
    print(f"Trials: {n:>8}, Average: {avg:.6f}")

print()
print("=" * 70)
print("最终结果")
print("=" * 70)

print(f"""
精确推导结果：
  稳态期望值 E = {E_steady}
  稳态期望值 E ≈ {float(E_steady):.6f}

蒙特卡洛验算：
  约为 1.777
""")
